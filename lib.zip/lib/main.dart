import 'package:flutter/material.dart';
import 'package:whatsapp_clone/app.dart';

void main() {
  runApp(const App());
}